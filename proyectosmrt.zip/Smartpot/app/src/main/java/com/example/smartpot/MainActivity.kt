package com.example.smartpot

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View


class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        Thread.sleep(2000)
        super.onCreate(savedInstanceState)
        setTheme(R.style.AppTheme)
        setContentView(R.layout.activity_splash)
    }
    fun registrar(view: View){
        val intent= Intent(this,Outview::class.java).apply {  }
        startActivity(intent)
    }
    fun acceder(view: View){
        val intent= Intent(this,home::class.java).apply {  }
        startActivity(intent)
    }
}