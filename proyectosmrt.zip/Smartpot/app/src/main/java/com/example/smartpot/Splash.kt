package com.example.smartpot

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.content.Intent

class Splash : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

    }
    fun registrar(view: View){
        val intent=Intent(this,Outview::class.java).apply {  }
        startActivity(intent)
    }
}