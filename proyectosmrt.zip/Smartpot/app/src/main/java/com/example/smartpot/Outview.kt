package com.example.smartpot

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View

class Outview : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_outview)

    }

    fun atras(view: View) {
        val intent = Intent(this, SplashActivity::class.java).apply { }
        startActivity(intent)
    }
}

